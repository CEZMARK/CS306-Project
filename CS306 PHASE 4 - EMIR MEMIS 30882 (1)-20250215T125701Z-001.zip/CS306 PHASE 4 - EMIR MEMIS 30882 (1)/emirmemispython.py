pip install pymongo
from pymongo import MongoClient

CONNECTION_STRING = "mongodb+srv://user789:emir1212@cluster0.8aw7dod.mongodb.net/?retryWrites=true&w=majority&appName=Cluster0"

client = MongoClient(CONNECTION_STRING)

db = client["VideoGameReviews"]

def create_collection(collection_name):
    db.create_collection(collection_name)
    print(f"Collection '{collection_name}' created!")

def read_all_data(collection_name):
    collection = db[collection_name]
    for document in collection.find():
        for key, value in document.items():
            print(f"{key}: {value}")
        print("\n")

def read_data_with_filter(collection_name, filter):
    collection = db[collection_name]
    for document in collection.find(filter):
        for key, value in document.items():
            print(f"{key}: {value}")
        print("\n") 

def insert_data(collection_name, data):
    collection = db[collection_name]
    collection.insert_one(data)
    print("Data inserted successfully!")

def delete_data(collection_name, filter):
    collection = db[collection_name]
    result = collection.delete_one(filter)
    if result.deleted_count > 0:
        print("Data deleted successfully!")
    else:
        print("No data found with the given filter.")

def update_data(collection_name, filter, new_data):
    collection = db[collection_name]
    result = collection.update_one(filter, {"$set": new_data})
    if result.matched_count > 0:
        print("Data updated successfully!")
    else:
        print("No data found with the given filter.")

def main():
    print("Welcome to Video Game Review Portal!")
    user_id = input("Please enter your user id: ")

    while True:
        print("\nPlease pick the option that you want to proceed.")
        print("1 - Create a collection.")
        print("2 - Read all data in a collection.")
        print("3 - Read some part of the data while filtering.")
        print("4 - Insert data.")
        print("5 - Delete data.")
        print("6 - Update data.")
        print("7 - Exit.")

        option = input("Selected option: ")

        if option == "1":
            collection_name = input("Enter the name of the collection to create: ")
            create_collection(collection_name)

        elif option == "2":
            collection_name = input("Enter the name of the collection to read: ")
            read_all_data(collection_name)

        elif option == "3":
            collection_name = input("Enter the name of the collection to read: ")
            filter_key = input("Enter the filter key: ")
            filter_value = input("Enter the filter value: ")
            read_data_with_filter(collection_name, {filter_key: filter_value})

        elif option == "4":
            collection_name = input("Enter the name of the collection to insert data: ")
            if collection_name == "GameReviews":
                game_title = input("Game title: ")
                review_message = input("Review message: ")
                rating = int(input("Rating (1-5): "))
                data = {
                    "game_title": game_title,
                    "review_message": review_message,
                    "user_id": user_id,
                    "rating": rating,
                    "timestamp": "2024-05-26T12:00:00Z"
                }
            elif collection_name == "ReviewComments":
                review_id = input("Review ID: ")
                comment = input("Comment: ")
                data = {
                    "review_id": review_id,
                    "user_id": user_id,
                    "comment": comment,
                    "timestamp": "2024-05-26T12:30:00Z"
                }
            insert_data(collection_name, data)

        elif option == "5":
            collection_name = input("Enter the name of the collection to delete data: ")
            filter_key = input("Enter the filter key: ")
            filter_value = input("Enter the filter value: ")
            delete_data(collection_name, {filter_key: filter_value})

        elif option == "6":
            collection_name = input("Enter the name of the collection to update data: ")
            filter_key = input("Enter the filter key: ")
            filter_value = input("Enter the filter value: ")
            new_data_key = input("Enter the new data key: ")
            new_data_value = input("Enter the new data value: ")
            update_data(collection_name, {filter_key: filter_value}, {new_data_key: new_data_value})

        elif option == "7":
            break

        else:
            print("Invalid option, please try again.")

if __name__ == "__main__":
    main()
