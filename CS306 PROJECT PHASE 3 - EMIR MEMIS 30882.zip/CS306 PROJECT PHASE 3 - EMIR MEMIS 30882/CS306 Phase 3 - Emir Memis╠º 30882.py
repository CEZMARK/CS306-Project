import pymysql

# Database Connection Setup
def get_connection():
    return pymysql.connect(host='localhost',
                           user='root',
                           password='Emir1212.',  
                           db='GovernmentTracking',  
                           charset='utf8mb4',
                           cursorclass=pymysql.cursors.DictCursor)

# Utility Function to Print Table Contents
def print_table_contents(table_name, limit=10):
    conn = get_connection()
    try:
        with conn.cursor() as cursor:
            sql = f"SELECT * FROM {table_name} LIMIT %s"
            cursor.execute(sql, (limit,))
            results = cursor.fetchall()
            print(f"Contents of {table_name}:")
            for row in results:
                print(row)
    finally:
        conn.close()

# CRUD Functions for Government Table
def create_government(gov_id, name, start_date, end_date):
    print("Before Insert:")
    print_table_contents('Government')
    
    conn = get_connection()
    try:
        with conn.cursor() as cursor:
            sql = "INSERT INTO Government (GovernmentID, Name, StartDate, EndDate) VALUES (%s, %s, %s, %s)"
            cursor.execute(sql, (gov_id, name, start_date, end_date))
        conn.commit()
    finally:
        conn.close()

    print("After Insert:")
    print_table_contents('Government')

def update_government(gov_id, name, start_date, end_date):
    print("Before Update:")
    print_table_contents('Government')
    
    conn = get_connection()
    try:
        with conn.cursor() as cursor:
            sql = "UPDATE Government SET Name = %s, StartDate = %s, EndDate = %s WHERE GovernmentID = %s"
            cursor.execute(sql, (name, start_date, end_date, gov_id))
        conn.commit()
    finally:
        conn.close()

    print("After Update:")
    print_table_contents('Government')

def delete_government(gov_id):
    print("Before Delete:")
    print_table_contents('Government')
    
    conn = get_connection()
    try:
        with conn.cursor() as cursor:
            sql = "DELETE FROM Government WHERE GovernmentID = %s"
            cursor.execute(sql, (gov_id,))
        conn.commit()
    finally:
        conn.close()

    print("After Delete:")
    print_table_contents('Government')

# CRUD Functions for Ministry Table
def create_ministry(ministry_id, name, ministry_function, government_id):
    print("Before Insert:")
    print_table_contents('Ministry')
    
    conn = get_connection()
    try:
        with conn.cursor() as cursor:
            sql = "INSERT INTO Ministry (MinistryID, Name, MinistryFunction, GovernmentID) VALUES (%s, %s, %s, %s)"
            cursor.execute(sql, (ministry_id, name, ministry_function, government_id))
        conn.commit()
    finally:
        conn.close()

    print("After Insert:")
    print_table_contents('Ministry')

def update_ministry(ministry_id, name, ministry_function):
    print("Before Update:")
    print_table_contents('Ministry')
    
    conn = get_connection()
    try:
        with conn.cursor() as cursor:
            sql = "UPDATE Ministry SET Name = %s, MinistryFunction = %s WHERE MinistryID = %s"
            cursor.execute(sql, (name, ministry_function, ministry_id))
        conn.commit()
    finally:
        conn.close()

    print("After Update:")
    print_table_contents('Ministry')

def delete_ministry(ministry_id):
    print("Before Delete:")
    print_table_contents('Ministry')
    
    conn = get_connection()
    try:
        with conn.cursor() as cursor:
            sql = "DELETE FROM Ministry WHERE MinistryID = %s"
            cursor.execute(sql, (ministry_id,))
        conn.commit()
    finally:
        conn.close()

    print("After Delete:")
    print_table_contents('Ministry')

if __name__ == '__main__':
    # Operations on Government
    create_government('GOV011', '47th Republic Government', '1989-11-10', '1991-06-23')
    update_government('GOV001', '36th Republic Government', '1973-04-15', '1974-01-25')
    delete_government('GOV010')

    # Operations on Ministry
    create_ministry('MIN011', 'Ministry of Youth and Sports', 'Responsible for regulating sports and youth activities', 'GOV003')
    update_ministry('MIN001', 'Ministry of Village Affairs and Cooperatives', 'Supports underdeveloped villages')
    delete_ministry('MIN010')
